package com.example.accountbook;

public class Accountbook_Item2 {
    public String id;
    public String pay;
    public String detail;
}
